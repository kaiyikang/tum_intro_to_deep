﻿Introduction:

We will build the classical GRU-based Sequence to Sequence with attention and the advanced Transformer model and train the model to perform simple translation tasks. Through this project, we can learn various advanced models and prepare for more relative topics in the future.

Instruction:

1, Operating Environment(default):Windows10 + Google-Colab
2, The three CSV-file should be also uploaded in Colab before running
3, Please import the file path by yourself in Colab during running